@extends('layouts.app')


@section('content')
    <div>
        <h2>Contact Us</h2>
    </div>
@endsection
