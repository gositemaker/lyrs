<div>
    <label>Name</label>
    <input type="text" name="name" required value="{{ $myName }}" />
</div>
