<p>Welcome to School Management System</p>
