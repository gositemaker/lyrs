<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ClassSubjectController extends Controller
{
    //
}
